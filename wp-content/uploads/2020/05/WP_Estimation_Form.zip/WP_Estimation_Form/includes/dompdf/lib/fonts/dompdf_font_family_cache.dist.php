<?php
//$rootDir = dirname(__FILE__);
//$distFontDir = $rootDir . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'fonts' . DIRECTORY_SEPARATOR;
return array(    
    'dejavu sans' =>
        array(
    'bold' => DOMPDF_DIR . '/lib/fonts/DejaVuSans-Bold',
    'bold_italic' => DOMPDF_DIR . '/lib/fonts/DejaVuSans-Bold',
    'italic' => DOMPDF_DIR . '/lib/fonts/DejaVuSans',
    'normal' => DOMPDF_DIR . '/lib/fonts/DejaVuSans'
        )    
);